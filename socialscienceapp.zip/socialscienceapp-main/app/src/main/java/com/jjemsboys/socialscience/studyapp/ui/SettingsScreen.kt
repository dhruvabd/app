package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.BookmarkManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(nav: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bookmarkManager = remember { BookmarkManager(context) }
    val darkMode by bookmarkManager.isDarkMode.collectAsState(initial = null)
    val completed by bookmarkManager.completedChapters.collectAsState(initial = emptySet())
    val saved by bookmarkManager.savedQa.collectAsState(initial = emptySet())

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, AppBorder)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.School, contentDescription = null, tint = AppAccent)
                        Column(Modifier.weight(1f)) {
                            Text("Learning Hub", fontWeight = FontWeight.Bold)
                            Text("Customize the app and keep your progress clean.", color = AppMuted)
                        }
                    }

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Dark mode", fontWeight = FontWeight.SemiBold)
                            Text("Use a deep, low-glare theme", color = AppMuted)
                        }
                        Switch(
                            checked = darkMode ?: false,
                            onCheckedChange = {
                                scope.launch { bookmarkManager.setDarkMode(it) }
                            }
                        )
                    }
                }
            }

            ActionCard(
                title = "Clear saved questions",
                description = "Remove all bookmarked questions from Saved.",
                icon = Icons.Default.DeleteSweep,
                onClick = { scope.launch { bookmarkManager.clearSavedQA() } }
            )

            ActionCard(
                title = "Reset chapter progress",
                description = "Mark all chapters as not completed.",
                icon = Icons.Default.Restore,
                onClick = { scope.launch { bookmarkManager.clearCompletedChapters() } }
            )

            Card(
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, AppBorder)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("App status", fontWeight = FontWeight.Bold)
                    Text("Saved items: ${saved.size}", color = AppMuted)
                    Text("Completed chapters: ${completed.size}", color = AppMuted)
                    Text("Theme: ${if ((darkMode ?: false)) "Dark" else "Light"}", color = AppMuted)
                }
            }
        }
    }
}

@Composable
private fun ActionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, AppBorder)
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Icon(icon, contentDescription = null, tint = AppAccent)
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(description, color = AppMuted)
            }
        }
    }
}
