package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.data.QA
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FlashcardScreen(nav: NavController, chapterId: String) {
    val cards: List<QA> = remember(chapterId) {
        if (chapterId == "all") {
            ChapterRepository.getAllQA()
        } else {
            ChapterRepository.chapters.find { it.id == chapterId }?.qa ?: emptyList()
        }
    }

    var shuffleSeed by remember(chapterId) { mutableIntStateOf(0) }
    var currentIdx by remember(chapterId) { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }

    val deck = remember(chapterId, shuffleSeed) {
        if (cards.isEmpty()) emptyList() else cards.shuffled(Random(shuffleSeed + 1))
    }
    val card = deck.getOrNull(currentIdx)
    val rotation by animateFloatAsState(targetValue = if (flipped) 180f else 0f, label = "flashcard_flip")

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Flashcards", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        shuffleSeed++
                        currentIdx = 0
                        flipped = false
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                    }
                }
            )
        },
        containerColor = AppBackground
    ) { padding ->
        if (deck.isEmpty() || card == null) {
            Column(
                Modifier.padding(padding).fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No flashcards available", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("This deck is empty.", color = AppMuted)
            }
            return@Scaffold
        }

        Column(
            Modifier.padding(padding).fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Tap the card to flip", color = AppMuted)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = (currentIdx + 1) / deck.size.toFloat(),
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = AppAccent,
                trackColor = AppBorder
            )
            Spacer(Modifier.height(10.dp))
            Text("${currentIdx + 1} of ${deck.size}", style = MaterialTheme.typography.labelLarge, color = AppMuted)

            Spacer(Modifier.height(18.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .graphicsLayer {
                        rotationY = rotation
                        cameraDistance = 12f * density
                    }
                    .clickable { flipped = !flipped },
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, AppBorder)
            ) {
                Box(
                    Modifier.fillMaxSize().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (rotation <= 90f) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(
                                Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(AppAccent),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.FlashOn, contentDescription = null, tint = Color.White)
                            }
                            Text("Question", style = MaterialTheme.typography.labelLarge, color = AppMuted)
                            Text(card.q, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = AppPrimary)
                        }
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.graphicsLayer { rotationY = 180f }
                        ) {
                            Box(
                                Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(AppAccent2),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.FlashOn, contentDescription = null, tint = Color.White)
                            }
                            Text("Answer", style = MaterialTheme.typography.labelLarge, color = AppMuted)
                            Text(card.a, style = MaterialTheme.typography.titleMedium, color = AppText)
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        flipped = false
                        currentIdx = if (currentIdx == 0) deck.lastIndex else currentIdx - 1
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(18.dp)
                ) { Text("Previous") }

                Button(
                    onClick = {
                        flipped = false
                        currentIdx = if (currentIdx == deck.lastIndex) 0 else currentIdx + 1
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(18.dp)
                ) { Text("Next", fontWeight = FontWeight.Bold) }
            }
        }
    }
}
