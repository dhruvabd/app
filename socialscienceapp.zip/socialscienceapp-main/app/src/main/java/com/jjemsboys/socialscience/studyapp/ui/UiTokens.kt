package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val AppBackground = Color(0xFFF5F7FB)
val AppSurface = Color(0xFFFFFFFF)
val AppSurfaceAlt = Color(0xFFF8FAFC)
val AppPrimary = Color(0xFF0F172A)
val AppAccent = Color(0xFF2563EB)
val AppAccent2 = Color(0xFF14B8A6)
val AppText = Color(0xFF334155)
val AppMuted = Color(0xFF64748B)
val AppSuccess = Color(0xFF16A34A)
val AppDanger = Color(0xFFDC2626)
val AppBorder = Color(0xFFDDE5F0)

val AppContentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)
