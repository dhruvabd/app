package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.BookmarkManager
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IndexScreen(nav: NavController) {
    val context = LocalContext.current
    val bookmarkManager = remember { BookmarkManager(context) }
    val savedIds by bookmarkManager.savedQa.collectAsState(initial = emptySet())
    val completedIds by bookmarkManager.completedChapters.collectAsState(initial = emptySet())
    val chapters = ChapterRepository.chapters

    val totalQuestions = remember { ChapterRepository.getAllQA().size }
    val totalChapters = chapters.size
    val savedCount = savedIds.size
    val completedCount = completedIds.size
    val nextChapter = chapters.firstOrNull { it.id !in completedIds } ?: chapters.firstOrNull()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Social Science Studio", fontWeight = FontWeight.Bold)
                        Text("Clean notes, quizzes, flashcards", style = MaterialTheme.typography.labelSmall, color = AppMuted)
                    }
                },
                actions = {
                    IconButton(onClick = { nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = null)
                    }
                    IconButton(onClick = { nav.navigate("settings") }) {
                        Icon(Icons.Default.Settings, contentDescription = null)
                    }
                }
            )
        },
        containerColor = AppBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF0F172A), Color(0xFF1D4ED8), Color(0xFF14B8A6))
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier
                                        .size(54.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.16f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.MenuBook, contentDescription = null, tint = Color.White)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Ready to learn?", color = Color.White.copy(alpha = 0.92f), fontWeight = FontWeight.Medium)
                                    Text("Your study dashboard", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                }
                            }

                            Text(
                                "Tap a chapter, revise notes, save answers, and practice quizzes in a clean iPhone-style layout.",
                                color = Color.White.copy(alpha = 0.88f)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                ActionPill("Chapters", Icons.Default.MenuBook) { nav.navigate("chapters") }
                                ActionPill("Quiz", Icons.Default.School) { nav.navigate("quiz") }
                                ActionPill("Saved", Icons.Default.Bookmarks) { nav.navigate("saved") }
                            }
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    SmallStatCard("Chapters", totalChapters.toString(), Icons.Default.MenuBook, Modifier.weight(1f))
                    SmallStatCard("Questions", totalQuestions.toString(), Icons.Default.Tune, Modifier.weight(1f))
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    SmallStatCard("Saved", savedCount.toString(), Icons.Default.Bookmarks, Modifier.weight(1f))
                    SmallStatCard("Done", completedCount.toString(), Icons.Default.CheckCircle, Modifier.weight(1f))
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, AppBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Continue learning", fontWeight = FontWeight.Bold)
                        Text(
                            nextChapter?.let { "${it.title} • ${it.subject}" } ?: "Everything is completed",
                            color = AppMuted
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { nav.navigate("chapters") },
                                shape = RoundedCornerShape(16.dp)
                            ) { Text("Open chapters") }

                            OutlinedButton(
                                onClick = { nav.navigate("settings") },
                                shape = RoundedCornerShape(16.dp)
                            ) { Text("Settings") }
                        }
                    }
                }
            }

            item {
                Text("Quick actions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    FeatureRow(
                        leftTitle = "Chapter Notes",
                        leftDesc = "Read every chapter neatly",
                        leftIcon = Icons.Default.MenuBook,
                        leftColor = AppAccent,
                        onLeftClick = { nav.navigate("chapters") },
                        rightTitle = "Flashcards",
                        rightDesc = "Tap to flip and revise",
                        rightIcon = Icons.Default.FlashOn,
                        rightColor = AppAccent2,
                        onRightClick = { nav.navigate("flashcard") }
                    )
                    FeatureRow(
                        leftTitle = "Practice Quiz",
                        leftDesc = "Random test mode",
                        leftIcon = Icons.Default.School,
                        leftColor = Color(0xFF7C3AED),
                        onLeftClick = { nav.navigate("quiz") },
                        rightTitle = "Saved Items",
                        rightDesc = "Your bookmarked Q&A",
                        rightIcon = Icons.Default.Bookmarks,
                        rightColor = Color(0xFF334155),
                        onRightClick = { nav.navigate("saved") }
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionPill(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(999.dp),
        color = Color.White.copy(alpha = 0.14f),
        contentColor = Color.White,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Text(text, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun SmallStatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, AppBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(AppAccent, AppAccent2))),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(title, color = AppMuted)
        }
    }
}

@Composable
private fun FeatureRow(
    leftTitle: String,
    leftDesc: String,
    leftIcon: androidx.compose.ui.graphics.vector.ImageVector,
    leftColor: Color,
    onLeftClick: () -> Unit,
    rightTitle: String,
    rightDesc: String,
    rightIcon: androidx.compose.ui.graphics.vector.ImageVector,
    rightColor: Color,
    onRightClick: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        FeatureTile(leftTitle, leftDesc, leftIcon, leftColor, Modifier.weight(1f), onLeftClick)
        FeatureTile(rightTitle, rightDesc, rightIcon, rightColor, Modifier.weight(1f), onRightClick)
    }
}

@Composable
private fun FeatureTile(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, AppBorder)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(color),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White)
            }
            Text(title, fontWeight = FontWeight.Bold)
            Text(desc, color = AppMuted)
        }
    }
}
