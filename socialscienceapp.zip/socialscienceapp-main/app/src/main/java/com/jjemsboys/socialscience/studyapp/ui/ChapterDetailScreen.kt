package com.jjemsboys.socialscience.studyapp.ui

import android.content.Intent
import android.net.Uri
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.BookmarkManager
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.data.QA
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterDetailScreen(nav: NavController, id: String) {
    val chapter = ChapterRepository.chapters.find { it.id == id } ?: return
    var query by remember { mutableStateOf("") }
    var showPreview by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bookmarkManager = remember { BookmarkManager(context) }
    val savedIds by bookmarkManager.savedQa.collectAsState(initial = emptySet())
    val completedIds by bookmarkManager.completedChapters.collectAsState(initial = emptySet())
    val isCompleted = completedIds.contains(chapter.id)

    val previewUrl = when (chapter.id) {
        "earth_living_planet" -> "https://drive.google.com/file/d/12kjoZTyZ6nQKtq9ZU3CAeBb7pDsHUwZ_/preview"
        "sources" -> "https://drive.google.com/file/d/1vTqL1Stq5z7JQUNJsL6Mc02SFrEVHb9K/preview"
        else -> ""
    }

    val downloadUrl = when (chapter.id) {
        "earth_living_planet" -> "https://drive.google.com/file/d/12kjoZTyZ6nQKtq9ZU3CAeBb7pDsHUwZ_/view"
        "sources" -> "https://drive.google.com/file/d/1vTqL1Stq5z7JQUNJsL6Mc02SFrEVHb9K/view"
        else -> ""
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(chapter.title, fontWeight = FontWeight.Bold)
                        Text(chapter.subject, style = MaterialTheme.typography.labelSmall, color = AppMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    if (previewUrl.isNotEmpty()) {
                        IconButton(onClick = { showPreview = !showPreview }) {
                            Icon(
                                imageVector = if (showPreview) Icons.Default.Close else Icons.Default.PictureAsPdf,
                                contentDescription = null
                            )
                        }
                    }
                }
            )
        },
        containerColor = AppBackground
    ) { padding ->
        if (showPreview && previewUrl.isNotEmpty()) {
            Column(Modifier.padding(padding).fillMaxSize()) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            webViewClient = WebViewClient()
                            settings.javaScriptEnabled = true
                            settings.setSupportZoom(true)
                            settings.builtInZoomControls = true
                            settings.displayZoomControls = false
                            settings.cacheMode = WebSettings.LOAD_NO_CACHE
                            settings.domStorageEnabled = true
                            settings.loadWithOverviewMode = true
                            settings.useWideViewPort = true
                            loadUrl(previewUrl)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, AppBorder)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        AssistChip(
                            onClick = {},
                            label = { Text(chapter.subtitle.uppercase()) }
                        )
                        Text(chapter.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(chapter.desc, color = AppText)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip(onClick = {}, label = { Text("${chapter.qa.size} questions") })
                            AssistChip(onClick = {}, label = { Text(chapter.subject) })
                            AssistChip(onClick = {}, label = { Text(if (isCompleted) "Completed" else "In progress") })
                        }
                    }
                }
            }

            if (previewUrl.isNotEmpty()) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { showPreview = true },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Preview")
                        }
                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Download")
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        scope.launch { bookmarkManager.toggleCompleteChapter(chapter.id) }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCompleted) AppAccent2 else AppAccent
                    )
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isCompleted) "Mark as not completed" else "Mark as completed", fontWeight = FontWeight.Bold)
                }
            }

            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search this chapter...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp)
                )
            }

            item {
                Text(
                    "${chapter.qa.count { it.q.contains(query, true) || it.a.contains(query, true) }} results",
                    color = AppMuted,
                    style = MaterialTheme.typography.labelLarge
                )
            }

            itemsIndexed(chapter.qa.filter {
                it.q.contains(query, true) || it.a.contains(query, true)
            }) { _, qa ->
                ExpandableQACard(
                    qa = qa,
                    isSaved = savedIds.contains(qa.id),
                    onToggleSave = { scope.launch { bookmarkManager.toggleSaveQA(qa.id) } }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpandableQACard(
    qa: QA,
    isSaved: Boolean = false,
    onToggleSave: (() -> Unit)? = null
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        onClick = { expanded = !expanded },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, AppBorder)
    ) {
        Column(Modifier.padding(16.dp).animateContentSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    Modifier
                        .padding(top = 2.dp)
                        .size(34.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(AppAccent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(qa.id.takeLast(2), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(qa.q, fontWeight = FontWeight.SemiBold, color = AppPrimary)
                    if (expanded) {
                        Text(qa.a, color = AppText)
                    }
                }

                if (onToggleSave != null) {
                    IconButton(onClick = onToggleSave) {
                        Icon(
                            imageVector = if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = null,
                            tint = if (isSaved) AppAccent2 else AppMuted
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (expanded) "Tap to hide answer" else "Tap to reveal answer",
                    style = MaterialTheme.typography.labelSmall,
                    color = AppMuted
                )
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = AppMuted
                )
            }
        }
    }
}
