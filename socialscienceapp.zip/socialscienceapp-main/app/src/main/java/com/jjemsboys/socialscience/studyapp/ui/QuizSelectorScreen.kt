package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Help
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import kotlinx.coroutines.delay

data class QuizQuestion(val q: String, val options: List<String>, val answer: Int)

val questionPool = mapOf(
    "earth_living_planet" to (1..20).map {
        QuizQuestion(
            "Earth Q$it: What is the largest continent?",
            listOf("Asia", "Africa", "Europe", "Australia"),
            0
        )
    },
    "sources" to (1..20).map {
        QuizQuestion(
            "Sources Q$it: Which is a primary source?",
            listOf("Textbook", "Newspaper", "Diary", "Documentary"),
            2
        )
    }
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizSelectorScreen(nav: NavController, mode: String) {
    val chapters = listOf("all" to "All Chapters - Random Mix") + ChapterRepository.chapters.map { it.id to it.title }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (mode == "test") "Test Mode" else "Practice Quiz", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                }
            )
        },
        containerColor = AppBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, AppBorder)
                ) {
                    Row(
                        Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(AppAccent, Color(0xFF7C3AED)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = Color.White)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Pick a quiz deck", fontWeight = FontWeight.Bold)
                            Text("Quiz mode has no timer. Test mode does.", color = AppMuted)
                        }
                    }
                }
            }

            items(chapters.size) { index ->
                val (id, name) = chapters[index]
                Card(
                    onClick = { nav.navigate("quiz_play/$id/$mode") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, AppBorder)
                ) {
                    Row(
                        Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(AppAccent2, AppAccent))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Help, contentDescription = null, tint = Color.White)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(name, fontWeight = FontWeight.Bold)
                            Text(if (id == "all") "Mixed questions from all chapters" else "Single chapter practice", color = AppMuted)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(nav: NavController, chapterId: String, mode: String) {
    val questions = remember(chapterId) {
        val base = if (chapterId == "all") questionPool.values.flatten() else questionPool[chapterId] ?: emptyList()
        base.shuffled().take(10)
    }

    var currentIdx by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var selectedIdx by remember { mutableStateOf<Int?>(null) }
    var timeLeft by remember { mutableIntStateOf(30) }
    var answered by remember { mutableStateOf(false) }

    LaunchedEffect(currentIdx, mode) {
        selectedIdx = null
        answered = false
        if (mode == "test") {
            timeLeft = 30
            while (timeLeft > 0 && !answered && currentIdx < questions.size) {
                delay(1000)
                timeLeft--
            }
            if (!answered && currentIdx < questions.size) {
                currentIdx++
            }
        }
    }

    if (questions.isEmpty()) {
        Scaffold(containerColor = AppBackground) { padding ->
            Column(
                Modifier.padding(padding).fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No questions available", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { nav.popBackStack() }) { Text("Back") }
            }
        }
        return
    }

    if (currentIdx >= questions.size) {
        val percent = score * 10
        Scaffold(containerColor = AppBackground) { padding ->
            Column(
                Modifier.padding(padding).fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, AppBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Quiz complete", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Score: $score / 10", style = MaterialTheme.typography.titleLarge)
                        Text("$percent%", color = if (score >= 7) AppSuccess else AppDanger, fontWeight = FontWeight.Bold)
                        LinearProgressIndicator(
                            progress = score / 10f,
                            modifier = Modifier.fillMaxWidth().height(10.dp),
                            color = if (score >= 7) AppSuccess else AppDanger,
                            trackColor = AppBorder
                        )
                        Button(
                            onClick = { nav.popBackStack() },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp)
                        ) { Text("Back to home", fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
        return
    }

    val question = questions[currentIdx]

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (mode == "test") "Test" else "Quiz", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                }
            )
        },
        containerColor = AppBackground
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (mode == "test") {
                LinearProgressIndicator(
                    progress = timeLeft / 30f,
                    modifier = Modifier.fillMaxWidth().height(10.dp),
                    color = if (timeLeft < 10) AppDanger else AppAccent,
                    trackColor = AppBorder
                )
                Text("Time left: ${timeLeft}s", fontWeight = FontWeight.Bold, color = AppMuted)
            }

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, AppBorder)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Question ${currentIdx + 1} of 10", style = MaterialTheme.typography.labelLarge, color = AppMuted)
                    Text(question.q, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
            }

            question.options.forEachIndexed { idx, option ->
                val bgColor = when {
                    !answered -> MaterialTheme.colorScheme.surface
                    idx == question.answer -> AppSuccess
                    idx == selectedIdx -> AppDanger
                    else -> MaterialTheme.colorScheme.surface
                }
                val textColor = when {
                    !answered -> AppPrimary
                    idx == question.answer || idx == selectedIdx -> Color.White
                    else -> AppPrimary
                }
                Card(
                    onClick = {
                        if (!answered) {
                            selectedIdx = idx
                            answered = true
                            if (idx == question.answer) score++
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = bgColor),
                    border = BorderStroke(1.dp, if (answered && idx == question.answer) AppSuccess else AppBorder),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text(
                        option,
                        modifier = Modifier.padding(16.dp),
                        color = textColor,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            if (answered) {
                Button(
                    onClick = { currentIdx++ },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text(if (currentIdx == 9) "Finish" else "Next question", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
